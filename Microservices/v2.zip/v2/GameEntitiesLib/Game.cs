using System.Collections.Generic;

namespace v2.shared
{
    public class Game
    {
        public int GameID {get; set;}
        public string GameTitle {get; set;}
        public string Genre {get; set;}
        public string ReleaseYear {get; set;}
        public string Description {get; set;}
    }
}